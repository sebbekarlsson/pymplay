from distutils.core import setup


setup(name='pymplay',
      version='1.0',
      packages=['pymplay'],
      modules=['MusicPlayer']
      )