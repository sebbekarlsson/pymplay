from distutils.core import setup


setup(name='pymplay',
      version='3.0',
      packages=['pymplay'],
      modules=['MusicPlayer']
      )
