from distutils.core import setup

setup(name='pymplay',
      version='1.0',
      py_modules=['pymplay/MusicPlayer'],
      )