from distutils.core import setup


setup(name='asp',
      version='1.0',
      packages=['pymplay'],
      )